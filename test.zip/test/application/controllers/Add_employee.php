<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Add_employee extends CI_Controller {

	public function __construct() {
        parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
        $this->load->model('Main_model');
		$this->load->library('upload');
    }
	public function index()
	{	
		$this->load->view('includes/header');
		$this->load->view('add-employee');
		$this->load->view('includes/footer');
	}
	public function do_upload()
	{	
		$flag=0;
		$config = array(
		'upload_path' => "uploads/",
		'allowed_types' => "gif|jpg|png|jpeg|pdf|csv",
		'overwrite' => TRUE,
		'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
		'max_height' => "768",
		'max_width' => "1024"
		);
		$this->upload->initialize($config);
		$this->load->library('upload', $config);
		if($this->upload->do_upload('userfile'))
		{
			$data = array('upload_data' => $this->upload->data());
			
			$count=0;
			$filename=$data['upload_data']['file_path'].'/'.$data['upload_data']['file_name'];
			$fp = fopen($filename,'r') or die("can't open file");
			$linecount = count(file($filename))-1;
			while($csv_line = fgetcsv($fp,1024))
			{	
				if(count($csv_line)<=5 && $linecount>=20)
				{
					$count++;
					if($count == 1)
					{
						continue;
					}//keep this if condition if you want to remove the first row
					for($i = 0, $j = count($csv_line); $i < $j; $i++)
					{	
						$validationDOB=$this->checkDateFormat($csv_line[3]);
						$validationJOD=$this->checkDateFormat($csv_line[4]);
						if($validationDOB==1 || $validationJOD==1)
						{
							$datas = array('error' => 'Please check correct date format(mm-dd-yyyy) of Date of Birth and Joining Date.');
							$flag=1;
						}
						else if($csv_line[0]!='' && $csv_line[1]!='' && $csv_line[2]!='')	
						{							
							$dateOfbirth=date("Y-m-d", strtotime($csv_line[3]));
							$joining_date=date("Y-m-d", strtotime($csv_line[4]));
							$insert_csv = array();
							$insert_csv['employee_code'] = $csv_line[0]; 
							$insert_csv['employee_name'] = $csv_line[1];
							$insert_csv['department'] = $csv_line[2];
							$insert_csv['date_of_birth'] = $dateOfbirth;
							$insert_csv['joining_date'] = $joining_date;
						}
						else
						{
							$datas = array('error' => 'Please fill all required fields in csv file.');
							$flag=1;
						}
					}
					$i++;
					if($insert_csv['employee_code']!='' && $insert_csv['employee_name']!='' && $insert_csv['department']!='' && $insert_csv['date_of_birth']!='' && $insert_csv['joining_date']!='')
					{
						$data = array(
							'employee_code' => $insert_csv['employee_code'] ,
							'employee_name' => $insert_csv['employee_name'],
							'department' => $insert_csv['department'],
							'date_of_birth' => $insert_csv['date_of_birth'],
							'joining_date' => $insert_csv['joining_date']
					   );
					   $this->Main_model->addData('employee',$data);
					   $datas = array('success' =>' Successfully stored the '.$i.' rows into the database');
					   $flag=0;
					}
					else
					{
						$datas = array('error' => 'Please fill all required fields in csv file.');
						$flag=1;
					}
				}
				else{
					$datas = array('error' => 'Should have a minimum of 5 columns and a maximum of 20 rows');//print_r($error);
					$flag=1;
				}
			}
		}
		else
		{
		$datas = array('error' => $this->upload->display_errors());
		$flag=1;
		}
		if($flag==1)
		{
			$this->load->view('includes/header');
			$this->load->view('add-employee',$datas);
			$this->load->view('includes/footer');
		}
		else 
		{	
			$datas = array('success' =>' Successfully stored the '.$i.' rows into the database');
			$datas['controller'] = 'View_employee'; 
			$this->load->view('includes/header');
			$this->load->view('add-employee',$datas);
			$this->load->view('includes/footer');
		}
	}
	function checkDateFormat($date) 
	{
		if (preg_match("/[0-31]{2}-[0-12]{2}-[0-9]{4}/", $date)) 
		{
				return 1;
		} 
		else 
		{
			return 0;
		}
	} 

	
}
