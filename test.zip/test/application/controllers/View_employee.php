<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class View_employee extends CI_Controller {

	public function __construct() {
        parent::__construct();
		$this->load->helper(array('form', 'url'));
        $this->load->model('Main_model');
    }
	public function index()
	{	
		$data['employees']=$this->Main_model->GetAllData('employee');
		$this->load->view('includes/header');
		$this->load->view('view-employees',$data);
		$this->load->view('includes/footer');
	}
}
