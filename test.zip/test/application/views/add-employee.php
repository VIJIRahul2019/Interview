<!DOCTYPE html>
<html lang="en">

<body class="aside-collapsed">
  <div class="wrapper">
    <!-- top navbar-->
    <header class="topnavbar-wrapper">
     <!-- START Top Navbar-->
     <nav role="navigation" class="navbar topnavbar">
      <!-- START navbar header-->
      <div class="navbar-header">
       <a href="#/" class="navbar-brand">
        <div class="brand-logo">
         <img src="#" alt="App Logo" class="logo">
       </div>
     </a>
   </div>
   <!-- END navbar header-->
   <!-- START Nav wrapper-->
   <div class="nav-wrapper">
     <!-- START Left navbar-->
     <ul class="nav navbar-nav">
      <li>
       <!-- Button used to collapse the left sidebar. Only visible on tablet and desktops-->
       <a href="#" data-trigger-resize="" data-toggle-state="aside-collapsed" class="hidden-xs togglemeu">
        <em class="icon-options-vertical"></em>
      </a>
      <!-- Button to show/hide the sidebar on mobile. Visible on mobile only.-->
      <a href="#" data-toggle-state="aside-toggled" data-no-persist="true" class="visible-xs sidebar-toggle togglemeu">
        <em class="icon-options-vertical"></em>
      </a>
    </li>
    <!-- START User avatar toggle-->
    <li>
      <h3 class="all-head">Upload CSV File</h3>  
    </li>
    <!-- END User avatar toggle-->
    <!-- START lock screen-->

    <!-- END lock screen-->
  </ul>
  <!-- END Left navbar-->
  <!-- START Right Navbar-->
  <ul class="nav navbar-nav navbar-right">
    <li>
     <a href="#" >
      <em class="fa fa-cog"></em>
    </a>
  </li>

  <li>
   <a href="#" data-toggle="modal" data-target="#myModal">
    <em class="fa fa-sign-out"></em>
  </a>
</li>
<!-- END Offsidebar menu-->
</ul>
<!-- END Right Navbar-->
</div>

</nav>
<!-- END Top Navbar-->
</header>
<!-- sidebar-->
<!-- header -->

<?php include_once("includes/sidebar.php") ?>

<section>
 <!-- Page content-->
 <div class="content-wrapper">
  <div class="container-fluid">
    <!-- <div class="row"> -->
      <div class="panel panel-default">
        <div class="panel-body">
		<form action="<?php echo base_url();?>add_employee/do_upload" method="post" enctype="multipart/form-data">
         <div class="row">
           <div class="col-md-6">				
				<label class="control-label">Select File</label>
				<input id="input-b5" name="userfile" type="file" multiple>					
           </div>
        </div>

  <div class="row">
	<div class="col-md-6">
		<span style="color:red;"><?php echo @$error;?></span>
		<span style="color:green;"><?php ini_set('max_execution_time', 120); echo @$success;?></span>	
		<?php
		if(@$success!='')
		{	
			redirect('View_employee');
		}
		?>
	</div>
    <div class="col-md-6">
        <button type="submit" class="btn btn-primary">Save Employees</button>
    </div>
  </div>
  </form>
</div>
</div>
<!-- </div> -->
</div>
</div>
</section>
<!-- Page footer-->
<footer class="footer">
 <span>&copy; <span id="demoyear"></span></span>
</footer>
</div>
</body>
</html>