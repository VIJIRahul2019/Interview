<head>
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
 <meta name="description" content="t">
 <meta name="keywords" content="t">
 <title>Employee CSV Upload</title>
 <!-- =============== VENDOR STYLES ===============-->
 <link rel="shortcut icon" href="<?php echo base_url(); ?>img/logo.jpg">
 <!-- FONT AWESOME-->
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/fontawesome/css/font-awesome.min.css">
 <!-- SIMPLE LINE ICONS-->
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/simple-line-icons/css/simple-line-icons.css">
 <!-- select2 -->
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/select2.css">
 <!-- select2 -->
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/select2-bootstrap.css">
 <!-- DATATABLES-->
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/js/datatables-colvis/css/dataTables.colVis.css">
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/js/datatables/media/css/dataTables.bootstrap.css">
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/index.css">
 <!-- datepicker -->
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-datetimepicker.min.css" >
 <!-- =============== BOOTSTRAP STYLES ===============-->
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.css" id="bscss">
 <!-- =============== APP STYLES ===============-->
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.css" id="maincss">
 <!-- =============== custom ===============-->
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/theme-a.css" id="maincss">
</head>