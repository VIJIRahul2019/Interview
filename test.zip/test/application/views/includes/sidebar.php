<!-- sidebar-->
<aside class="aside">
 <!-- START Sidebar (left)-->
 <div class="aside-inner">
  <nav data-sidebar-anyclick-close="" class="sidebar">
   <!-- START sidebar nav-->
   <ul class="nav">
    <!-- START user info-->
    <li class="has-user-block">
     <div class="user-box-menu">
      <div class="item user-block">
       <!-- User picture-->
       <div class="user-block-picture">
        <div class="user-block-status">
         <!-- <img src="img/avatar5.png" alt="Avatar" width="60" height="60" class="img-thumbnail img-circle"> -->
         <!-- <div class="circle circle-success circle-lg"></div> -->
       </div>
     </div>
     <!-- Name and Employee-->
     <div class="user-block-info">
      <span class="user-block-name"></span>
      <span class="user-block-role"></span>
    </div>
  </div>
</div>
</li>
<li>
 <a href="<?php echo base_url();?>View_employee" title="Employee">
  <em class="fa fa-briefcase"></em>
  <span>Employees</span>
</a>
</li>
</ul>

<!-- END sidebar nav-->
</nav>
</div>
<!-- END Sidebar (left)-->
</aside>