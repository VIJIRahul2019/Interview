<body class="aside-collapsed">
 <div class="wrapper">
  <!-- top navbar-->
  <header class="topnavbar-wrapper">
   <!-- START Top Navbar-->
   <nav role="navigation" class="navbar topnavbar">
    <!-- START navbar header-->
    <div class="navbar-header">
     <a href="#/" class="navbar-brand">
      
   </a>
 </div>
 <!-- END navbar header-->
 <!-- START Nav wrapper-->
 <div class="nav-wrapper">
   <!-- START Left navbar-->
   <ul class="nav navbar-nav">
    <li>
     <!-- Button used to collapse the left sidebar. Only visible on tablet and desktops-->
     <a href="#" data-trigger-resize="" data-toggle-state="aside-collapsed" class="hidden-xs togglemeu">
      <em class="icon-options-vertical"></em>
    </a>
    <!-- Button to show/hide the sidebar on mobile. Visible on mobile only.-->
    <a href="#" data-toggle-state="aside-toggled" data-no-persist="true" class="visible-xs sidebar-toggle togglemeu">
      <em class="icon-options-vertical"></em>
    </a>
  </li>
  <!-- START User avatar toggle-->
  <li>
    <h3 class="all-head">View Employees</h3>  
  </li>
  <!-- END User avatar toggle-->
  <!-- START lock screen-->

  <!-- END lock screen-->
</ul>
<!-- END Left navbar-->
<!-- START Right Navbar-->
<ul class="nav navbar-nav navbar-right">
  <li>
   <a href="#" >
    <em class="fa fa-cog"></em>
  </a>
</li>

<li>
 <a href="#" data-toggle="modal" data-target="#myModal">
  <em class="fa fa-sign-out"></em>
</a>
</li>
<!-- END Offsidebar menu-->
</ul>
<!-- END Right Navbar-->
</div>

</nav>
<!-- END Top Navbar-->
</header>
<!-- sidebar-->
<!-- header -->
<?php include_once("includes/sidebar.php") ?>
<section>
 <!-- Page content-->
 <div class="content-wrapper">

  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12" style="padding-right: 16px;">
				<span style="color:green;"><?php echo @$success;?></span>	
        <div class="pull-right">
          <a href="add_employee" class="btn btn-sm btn-primary" style="margin-bottom: 5px;">
            Add Employee  <em class="fa fa-plus"></em>
          </a>
        </div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-body">

        <div class="table-responsive">
          <table id="datatable2" class="table table-striped table-hover">
           <thead>
            <tr>
             <th>Sl.No</th>
			 <th>Employee Code</th>
             <th>Employee Name</th>             
             <th>Department</th>
             <th>Age</th>
             <th>Experience in the organization</th>
           </tr>
         </thead>
         <tbody>
		 <?php
		 if(!empty($employees))
		 {
			 $i=1;
			 foreach($employees as $row)
			 {	
				//for age calculating
				$date_of_birth =$row['date_of_birth'];
				$today = date('Y-m-d');
				$diff = abs(strtotime($today) - strtotime($date_of_birth));
				$age = floor($diff / (365*60*60*24));
				
				//for experience calculating
				$joining_date = $row['joining_date'];
				$diff = abs(strtotime($today) - strtotime($joining_date));
				$years = floor($diff / (365*60*60*24));
				$months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
				$experience=$years.' years and '.$months.' months';
			 ?>
			  <tr>
				<td><?php echo $i?></td>
				<td><?php echo $row['employee_code'];?></td>
				<td><?php echo $row['employee_name'];?></td>
				<td><?php echo $row['department'];?></td>
				<td><?php echo $age;?></td> 
				<td><?php echo $experience;?></td>
			  </tr>
			  <?php
			  $i++;
			 }
		 }
		 else
		 {
			 ?>
			 <tr>
				<td colspan="6" style="text-align:center;">No Data Available.</td>
			 </tr>
			 <?php
		 }
		  ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div>
</section>
<!-- Page footer-->
<footer class="footer">
 <span>&copy; <span id="demoyear"></span></span>
</footer>
</div>
</body>
</html>