<?php
class Main_model extends CI_Model {
	
	 public function __construct() {
        parent::__construct();
    }
	
	public function addData($table,$data)
	{
		$this->db->insert($table,$data);
        return true;
	}
	public function GetAllData($table)
	{
		$this->db->select("*");
		$this->db->from($table);
		$query = $this->db->get();
		return $result =  $query->result_array();
	}
}
?>